package thigk2.nguyenhoangluu.qlsanpham;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class QlSanPhamApplicationTests {

	@Test
	void contextLoads() {
	}

}
